"""Calculate the beam pattern from a line array.

The array consists of N elements described either as points or rectangular
elements.
Results are calculated in the far-field of the array, using the
Fraunhofer-Approximation.

An interactive version can be run from the Jupyter Notebook 'array_demo.ipynb'
"""

# Python libraries
from math import pi
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import ipywidgets as widgets

# Internal libraries
import beamplot_utilities as bpu


# Class definitions
class WidgetLayout():
    """Container for widgets and layout."""

    def __init__(self, layout, widget):
        self.layout = layout
        self.widget = widget


class Array():
    """Define, calculate, and display transducer beam profile."""

    def __init__(self, create_widgets=False):

        # Transducer array definition
        self.n_elements = 32    # Number of elements in array
        self.kerf = 100e-6      # m   Kerf between elements
        self.pitch = 7.5e-3     # m   Pitch between elements
        self.frequency = 100e3  # Hz  Ultrasound frequency
        self.angle_s = 20       # deg Steering angle
        self.c = 1500           # m/s Speed of soundin load medium

        # Display settings
        self.theta_max = 90    # deg  Max. angle to calculate
        self.x_max = 70.0      # m    Max. lateral dimension to calculate
        self.z_max = 140.0     # m    Max. depth to calculate
        self.n_x = 300         # No. of points in the x-direction (azimuth)
        self.n_z = 400         # No. of points in the z-direction (depth)
        self.db_range = 60     # dB   Dynamic gange on dB-scales
        self.db_gain = 6       # dB   Max. on dB-scales
        self.db_polar = 30     # dB   Dynamic range on polar plot

        # Colors and markers
        self.text_face = 'whitesmoke'
        self.element_color = 'crimson'

        self.colormap = 'inferno'
        self.intensity_background = 'black'

        # Initialisation
        self.axes, self.fig = self._initialise_graphs()
        self.scale_axes()

        if create_widgets:
            self.widget = self._create_widgets()

    # === Calculated parameters ===========================
    def theta_s(self):
        """Steering angle in radians.."""
        return np.radians(self.angle_s)

    def delay(self):
        """Delay between elements (no focusing)."""
        return -np.sin(self.theta_s()) * self.pitch / self.c

    def delay_array(self):
        """Delay over all elements."""
        nc = 1/2*(self.n_elements+1)

        n = np.arange(0, self.n_elements)+1
        tau = -(n-nc) * self.delay()
        tau = tau
        return [tau, n]

    def width(self):
        """Width of element."""
        return self.pitch - self.kerf

    def wavelength(self):
        """Calculate acoustic wavelenght."""
        return self.c/self.frequency

    def d_aperture(self):
        """Width of aperture."""
        return self.n_elements * self.pitch - self.kerf

    def p_lambda(self):
        """Pitch relative to wavelength."""
        return self.pitch / self.wavelength()

    def w_lambda(self):
        """Element width relative to wavelength."""
        return self.width() / self.wavelength()

    def d_lambda(self):
        """Aperture width relative to wavelength."""
        return self.d_aperture() / self.wavelength()

    def z_r(self):
        """Rayleigh distance, far-field limit."""
        return self.d_aperture()**2/(2*self.wavelength())

    def z_c(self):
        """Limit reference distance to outside far-field limit."""
        return np.max([self.z_ref, self.z_r()])

    # === Axial plane ===================
    def x(self):
        """Lateral dimension for axial plot (x or y)."""
        return np.linspace(-self.x_max, self.x_max, self.n_x)

    def z(self):
        """Axial dimension (depth) for axial plot (z)."""
        return np.linspace(self.z_r(), self.z_max, self.n_z)

    def zx(self):
        """Axial plane (zx or zy) to plot."""
        pts = np.meshgrid(self.z(), self.x())
        return pts

    def r(self):
        """Distance from aperture centre for axial plot."""
        return np.sqrt(self.zx()[0]**2 + self.zx()[1]**2)

    def theta(self):
        """Azimuth(x) angle to point(z, x)."""
        return np.arctan2(self.zx()[1], self.zx()[0])

    def directivity_element(self, theta):
        """Directivity of one element."""
        return np.sinc(self.w_lambda() * np.sin(theta))

    def directivity_array_points(self, theta):
        """Directivity of arrray of points."""
        s_theta = np.sin(theta) - np.sin(self.theta_s())
        x = pi * self.p_lambda() * s_theta
        x[x == 0] = 1e-4   # Avoid 0/0 erroers
        d = np.sin(self.n_elements * x) / (self.n_elements * np.sin(x))

        return d

    def p_axial(self):
        """Calculate axial pressure field in the azimuth plane (zx)."""
        p0 = self.n_elements * self.width() / self.r()
        p = p0 * self.directivity_element(self.theta()) * \
            self.directivity_array_points(self.theta())

        return p

    # === Commands =============================
    def display(self):
        """Display beam pattern in graphs."""
        self._remove_old_artists()
        ax = self.axes

        # Intensity, azimuth plane
        p_ref = self.n_elements * self.width() / self.z_r()
        p_db = bpu.db(self.p_axial(), p_ref=p_ref)

        im = ax['axial'].pcolormesh(self.x(), self.z(),  p_db.transpose(),
                                    clim=self._db_scale(),
                                    cmap=self.colormap)

        self.cbar = self.fig.colorbar(im, ax=ax['axial'])
        bpu.db_colorbar(self.cbar, db_sep=6)

        # Illustrate aray
        ax['axial'].fill(self.d_aperture()*np.array([-1, 1, 1, -1])/2,
                         self.z_r()*np.array([0, 0, 1, 1]),
                         color=self.element_color,
                         alpha=0.7)

        # Delay profile
        tau, n = self.delay_array()
        ax['delay'].stem(n, tau*1e6, 'C0')

        # Directivity plot, polar
        theta = np.linspace(-pi/2, pi/2, 500)
        p_element = self.directivity_element(theta)
        p_points = self.directivity_array_points(theta)
        p_array = p_element * p_points

        ax['beamprofile'].plot(theta, bpu.db(p_element, p_ref=1),
                               color='C0', linestyle='dashed')

        ax['beamprofile'].plot(theta, bpu.db(p_array, p_ref=1),
                               color='C0', linestyle='solid')

        # Scaling, text box
        self.scale_axes()
        self._resulttext()

        return

    def scale_axes(self):
        """Change scales of all graphs."""
        ax = self.axes

        # Axial beam profile, intensity plot
        ax["axial"].set(xlim=self.x_max*np.array([-1, 1]),
                        ylim=(self.z_max, 0))

        # Delay profile
        delay_max = 1e6 * 1/2 * self.n_elements * self.pitch / self.c
        ax['delay'].set(xlim=(1, self.n_elements),
                        ylim=(-delay_max, delay_max))
        bin_log = np.floor(np.log2(self.n_elements))
        dn = 2**(bin_log-2)  # 4 power-of-2 scaled ticks

        ax['delay'].set_xticks(np.arange(1, self.n_elements), minor=True)
        ax['delay'].set_xticks(np.arange(0, self.n_elements+1, dn))

        # Directivity plot, polar
        ax['beamprofile'].set(thetamin=-90,
                              thetamax=+90,
                              theta_zero_location='S',
                              rmin=-self.db_polar,
                              rmax=0.0,
                              rticks=[-20, -6, 0]) #np.flip(np.arange(0, -self.db_polar, -6)))

        ax['beamprofile'].set_title('Radiation Diagram [dB re. max]', y=0)

        return 0

    def interact(self,
                 n_elements=None,
                 frequency=None,
                 pitch=None,
                 angle_s=None,
                 db_range=None,
                 db_gain=None
                 ):
        """Scale inputs and  display results.

        For interactive operation with dimensions in mm and frequency in kHz.
        Existing values are used if a parameter is omitted.

        Parameters
        ----------
        n_elements: int, optional
            No. of elements in array
        frequency: float, optional
            Frequency in kHz
        pitch: float, optional
            Element pitch in mm
        angle_s: float, optional
            Steering angle in degrees
        db_range: float
            Range on dB-axes
        db_gain: float
            Maximum on dB-axes
        """
        if n_elements is not None:
            self.n_elements = n_elements
        if frequency is not None:
            self.frequency = 1e3*frequency
        if pitch is not None:
            self.pitch = 1e-3*pitch
        if angle_s is not None:
            self.angle_s = angle_s
        if db_range is not None:
            self.db_range = db_range
        if db_gain is not None:
            self.db_gain = db_gain

        # Display result in graphs
        self.display()

        return

    # === Non-public methods ==========================================

    # Graphs and results
    def _db_scale(self):
        db_lim = np.array([-self.db_range, 0]) - self.db_gain
        return db_lim

    def _resulttext(self):
        """Text box for lateral profile results."""
        header = (f'Frequency  $f$ = {self.frequency/1e3:.0f} kHz\n'
                  fr'Wavelength  $\lambda$ = {self.wavelength()*1e3:.1f} mm')

        array_text = (r'No. of elements $N_{el}$ = '
                      f'{self.n_elements:d} '
                      '\n'
                      f'Element width $w$ = {self.width()*1e3:.2f}'
                      '\n'
                      f'Kerf $w$ = {self.kerf*1e3:.3f} mm'
                      '\n'
                      f'Pitch $d$ = {self.pitch*1e3:.2f} mm'
                      f' = {self.p_lambda():.2f}'
                      r' $\lambda$'
                      '\n'
                      f'Array width $D$ = {self.d_aperture()*1e3:.0f} mm'
                      f' = {self.d_lambda():.1f}'
                      r' $\lambda$'
                      )

        angle_text = (r'Steering angle $\theta_s$ = '
                      fr'{self.angle_s:.1f}$^\circ$')

        distance_text = (r'Rayleigh distance $z_R$ = '
                         f'{self.z_r():.2f} m')

        result_text = header + '\n' + array_text + \
            '\n' + angle_text + '\n' + distance_text

        bpu.set_fig_text(self.fig, result_text, xpos=0.02, ypos=0.35)

        return

    def _initialise_graphs(self):
        """Initialise result graphs."""
        plt.close('all')
        fig = plt.figure(figsize=[15, 5],
                         constrained_layout=True,
                         num='Array Beamprofile')
        bpu.add_logo(fig)

        gs = GridSpec(4, 4, figure=fig)
        ax = {'axial': fig.add_subplot(gs[0:, 2:]),
              'delay': fig.add_subplot(gs[0, 1]),
              'beamprofile': fig.add_subplot(gs[1:, 1], projection='polar')}

        # Axial intensity plot
        ax['axial'].set(aspect='equal',
                        ylabel='Depth (z) [m]',
                        xlabel='Azimuth (x) [m]',
                        facecolor=self.intensity_background)

        # Delay graph
        ax['delay'].set(xlabel='Element no.',
                        ylabel=r'Delay [$\mu$s]')

        ax['delay'].grid(visible=True, which='major')

        return ax, fig

    def _remove_old_artists(self):
        for ax in self.axes.values():
            bpu.remove_artists(ax)

        try:
            self.cbar.remove()
        except Exception:
            pass

        return 0

    # Interactive widgets
    def _create_widgets(self):
        """Create widgets for interactive operation."""
        title = 'Beam-profile from Single Element Transducer'
        title_widget = widgets.Label(title, style=dict(font_weight='bold'))

        text_layout = {'continuous_update': False,
                       'layout': widgets.Layout(width='95%'),
                       'style': {'description_width': '50%'}}

        slider_layout = {'continuous_update': True,
                         'layout': widgets.Layout(width='95%'),
                         'style': {'description_width': '30%'}}

        text_width = '20%'
        slider_width = '60%'

        # Text widgets (Dropboxes, number boxes)
        n_elements_widget = widgets.BoundedIntText(
            value=64, min=1, max=1024, step=1,
            description='No. of elements',
            **text_layout)

        frequency_widget = widgets.BoundedFloatText(
            value=100, min=1, max=400, step=1,
            description='Frequency [kHz]',
            **text_layout)

        pitch_widget = widgets.BoundedFloatText(
            value=7.5, min=0.1, max=100, step=0.1,
            description='Element pitch [mm]',
            **text_layout)

        db_range_widget = widgets.BoundedFloatText(
            value=60, min=6, max=120, step=6,
            description='Range [dB]',
            **text_layout)

        db_gain_widget = widgets.BoundedFloatText(
            value=0, min=-120, max=120, step=6,
            description='Gain [dB]',
            **text_layout)

        col_par = widgets.VBox([n_elements_widget,
                                frequency_widget,
                                pitch_widget],
                               layout=widgets.Layout(width=text_width))

        col_db = widgets.VBox([db_range_widget,
                               db_gain_widget],
                              layout=widgets.Layout(width=text_width))

        # Slider widgets
        steering_angle_widget = widgets.FloatSlider(
            min=-90, max=90,
            value=0, step=1,
            readout_format='.0f',
            description='Steering angle [Deg.]',
            **slider_layout)

        col_slider = widgets.VBox([steering_angle_widget],
                                  layout=widgets.Layout(width=slider_width))

        widget_layout = widgets.HBox([col_par, col_db, col_slider],
                                     layout=widgets.Layout(width='80%'))

        widget_layout = widgets.VBox([title_widget, widget_layout])

        widget = {'n_elements': n_elements_widget,
                  'frequency': frequency_widget,
                  'pitch': pitch_widget,
                  'db_range': db_range_widget,
                  'db_gain': db_gain_widget,
                  'steering_angle': steering_angle_widget,
                  }

        w = WidgetLayout(widget_layout, widget)

        return w
